package it.fi.meucci;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;
import com.fasterxml.jackson.databind.ObjectMapper;



public class Client {
    
    String nomeServer = "localhost";
    int porta = 3456;
    Socket socket;    
    String stringainviata;
    String stringaRicevuta;
    
    
    BufferedReader tastiera; // faccio lo stream
    DataOutputStream outVersoIlServer;
    BufferedReader inDalServer;

    public Socket connetti(){
        
        try {
            
            ObjectMapper objectMapper = new ObjectMapper();

            tastiera = new BufferedReader(new InputStreamReader(System.in));
            socket = new Socket(nomeServer, porta); 

            outVersoIlServer = new DataOutputStream(socket.getOutputStream());
            inDalServer = new BufferedReader(new InputStreamReader( socket.getInputStream() ));


            ArrayList<Biglietto> vuoto = new ArrayList<>();  // creo l'arraylist di biglietti vuoti
            Messaggio m = new Messaggio(vuoto);

            outVersoIlServer.writeBytes(objectMapper.writeValueAsString(m) + "\n");

            String bigliettiDisponibili = inDalServer.readLine();
            Messaggio message= objectMapper.readValue(bigliettiDisponibili, Messaggio.class);

            System.out.println("I biglietti sono ora DISPONIBILI");   // stampo i biglietti disponibili con id e numero
            for (int i = 0; i < message.biglietti.size(); i++) {
                System.out.println("ID: " + message.biglietti.get(i).ID + " - " + message.biglietti.get(i).numero);
            }

        } catch (Exception e) {
            System.out.println("error"); // esce dalla funzione 
        }

        return socket;
    }


    public void comunica(){
        try {
            
                ArrayList<Biglietto> bcomprare= new ArrayList<>();
                System.out.print("Scrivi gli ID dei biglietti");
                stringaRicevuta = tastiera.readLine();
                String[] stringa = stringaRicevuta.split(" "); // prendo la stringa che ho ricevuto e "metto" gli spazi

                for (int i = 0 ; i<stringa.length; i++){
                    Biglietto biglietto = new Biglietto( Integer.parseInt( stringa[i] ), " ");
                    bcomprare.add(biglietto); // aggiungo all'array di biglietti da comprare il nuovo boglietto
                }

                ObjectMapper objectMapper = new ObjectMapper();

                Messaggio m = new Messaggio(bcomprare);
                outVersoIlServer.writeBytes(objectMapper.writeValueAsString(m) + "\n");

                String risposta = inDalServer.readLine();
                Messaggio messaggioricevuto = objectMapper.readValue(risposta, Messaggio.class);

                System.out.println("I biglietti acquistat siono :");  // mi stampa i biglietto che ho comprato 
                for (int i = 0; i < messaggioricevuto.biglietti.size(); i++) {
                    System.out.println("ID: " + messaggioricevuto.biglietti.get(i).ID + " - " + messaggioricevuto.biglietti.get(i).numero);
                }

                
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


}
