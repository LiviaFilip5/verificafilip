package it.fi.meucci;

public class Biglietto {
    int ID;                             // creo gli attributi del biglietto
    String numero;

    
    public Biglietto(int iD, String numero) {
        ID = iD;
        this.numero = numero;
    }
    


    public Biglietto() {
    }



    public int getID() {
        return ID;
    }


    public void setID(int iD) {
        ID = iD;
    }


    public String getNumero() {
        return numero;
    }


    public void setNumero(String numero) {
        this.numero = numero;
    }
    


    

    

    


    
    
}

