package it.fi.meucci;

import java.io.BufferedReader;
import java.io.DataOutputStream;

import java.io.InputStreamReader;

import java.net.Socket;
import java.util.ArrayList;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ServerThread extends Thread{
    Socket client = null;

    BufferedReader inDalClient = null;
    DataOutputStream outVersoIlClient = null;

    ServerThread(Socket client ){
        this.client = client;
    }

    public void run(){
        try {
            this.comunica();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void comunica() throws Exception{
        inDalClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
        outVersoIlClient = new DataOutputStream(client.getOutputStream());
        
       ObjectMapper objectMapper = new ObjectMapper();
        while(true){
            String stringaricevuta = inDalClient.readLine();
            Messaggio message= objectMapper.readValue(stringaricevuta, Messaggio.class); //deserializzazione perchè "leggo"

            if (message.getBiglietti().size() == 0){  // guardo se l'array è vuoto
                Messaggio messaggio = new Messaggio (ServerMain.biglietti);
                outVersoIlClient.writeBytes(objectMapper.writeValueAsString(messaggio) + "\n");
            } else {

                ArrayList<Biglietto> bigliettipresi = new ArrayList<>();

                for (int i = 0; i < message.getBiglietti().size(); i++) {
                    for (int j = 0; j < ServerMain.biglietti.size(); j++) {
                        if (message.getBiglietti().get(i).ID == ServerMain.biglietti.get(j).ID){
                            bigliettipresi.add(message.getBiglietti().get(i));
                            ServerMain.biglietti.remove(j);
                            j--;
                        }
                    }
                }

                Messaggio messaggio = new Messaggio(bigliettipresi);
                outVersoIlClient.writeBytes(objectMapper.writeValueAsString(messaggio) + "\n");  // serealizzazione perchè "scrivo"
            }
        }
    } 
}
