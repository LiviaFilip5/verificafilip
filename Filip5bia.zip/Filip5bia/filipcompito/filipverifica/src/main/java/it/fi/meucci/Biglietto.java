package it.fi.meucci;



public class Biglietto {
    int ID;                             // creo gli attributi del biglietto
    String numero;

    
    public Biglietto(int iD, String numero) {
        ID = iD;
        this.numero = numero;
    }

    


    public Biglietto() {  //costruttore vuoto
    }




    public  int getID() {
        return ID;
    }


    public String getNumero() {
        return numero;
    }


    public  void setID(int iD) {
        ID = iD;
    }


    public void setNumero(String numero) {
        this.numero = numero;
    }

    
}
