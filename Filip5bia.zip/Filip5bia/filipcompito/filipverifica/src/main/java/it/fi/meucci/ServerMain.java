package it.fi.meucci;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class ServerMain {


    private ServerSocket serverSocket;      //  creo il socket
    private ArrayList<ServerThread> listathread = new ArrayList<>(); 

    public static ArrayList<Biglietto> biglietti = new ArrayList<>();
    

    public ServerMain(){
        Biglietto b1 = new Biglietto (4, "palco-1a,");  // creo i biglietti con id e numero
        Biglietto b2 = new Biglietto (7, "tribuna-2c");
        Biglietto b3 = new Biglietto(10, "parterre-7a");
        Biglietto b4 = new Biglietto (6, "parterre-7a");
        Biglietto b5 = new Biglietto (2, "palco-1a,");
        Biglietto b6 = new Biglietto(9, "tribuna");
        Biglietto b7 = new Biglietto (5, "tribuna-2c");

        biglietti.add(b1);  // aggiungo i biglietti creati all'array
        biglietti.add(b2);
        biglietti.add(b3);
        biglietti.add(b4);
        biglietti.add(b5);
        biglietti.add(b6);
        biglietti.add(b7);
        


        

        
    }

    public void avvia(){
        try {
            System.out.println("Start");
            this.serverSocket = new ServerSocket(3456); // creo la porta nella quale verrà avviato il server 3456

            while (true) {        // faccio un ciclo così che i client vengano accettati all'infinito                      

                Socket socket = serverSocket.accept();  // con la funziona accept faccio collgare il primo client e successivamente instauro la connessione cxreando il socket
                ServerThread thread = new ServerThread(socket);
                this.listathread.add(thread);
                thread.start();
                                

            }

        } catch (Exception e) {
            System.out.println("Fine");  // esco 
        }        
    }
    

}
