package it.fi.meucci;

import java.util.ArrayList;

public class Messaggio {   // creo la classe con costruttore get e set
    public static final int ID = 0;
    ArrayList <Biglietto> biglietti = new ArrayList<>();
    public Messaggio(ArrayList<Biglietto> biglietti) {
        this.biglietti = biglietti;
    }  

    
    public Messaggio() {
    }


    public static int getId() {
        return ID;
    }
    public ArrayList<Biglietto> getBiglietti() {
        return biglietti;
    }
    public void setBiglietti(ArrayList<Biglietto> biglietti) {
        this.biglietti = biglietti;
    }

    
    

    

    


    
    
}