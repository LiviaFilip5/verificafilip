package it.fi.meucci;

/**
 * Hello world!
 *
 */
public class App 
{
    /**
     * @param args
     */
    public static void main( String[] args )
    {
        ServerMain azione = new ServerMain();
        azione.avvia();
    }
}
